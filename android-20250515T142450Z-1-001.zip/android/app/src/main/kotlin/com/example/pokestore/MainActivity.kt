package com.example.pokestore

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
